﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class AgentResultModel
    {
        public AgentModel Agent { get; set; }
        public List<AgentModel> Agents { get; set; }
    }
}
