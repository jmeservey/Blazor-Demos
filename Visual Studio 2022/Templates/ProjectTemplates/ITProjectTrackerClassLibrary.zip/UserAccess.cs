﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class UserAccess
    {
        public static List<string> AdminList = new List<string>() { "lucas.poppe", "joshua.meservey", "nikki.krumm" };    
    }
}
